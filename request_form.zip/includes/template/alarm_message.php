<!DOCTYPE html>
<html land='en'>
 <head>
    <meta name='viewport'
    content="width=device-width,
    initial-scale=1.0">
    <title>Touch Sensor Alarm</title>
    <style></style>
 </head>
 <body>
  <div id="touchArea">Touch Here</div>
  <div id="alarmMessage">Alarm Triggered!</div>
 </body>
 </html>